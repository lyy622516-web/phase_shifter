/**
  * @file    main.c
  * @brief   USART1 serial test for CS32F030C8T6.
  */

#include "main.h"
#include "cs32f0xx_gpio.h"
#include "cs32f0xx_rcu.h"
#include "cs32f0xx_usart.h"

#define LED_GPIO_PORT       GPIOA
#define LED_GPIO_PIN        GPIO_PIN_15
#define UART_BAUD_RATE      115200U
#define RX_LINE_CAPACITY    64U

static volatile uint32_t system_millis;
static uint32_t wall_clock_base_seconds;

void SysTick_Handler(void)
{
    ++system_millis;
}

static void led_init(void)
{
    gpio_config_t gpio_config;

    rcu_ahb_periph_clock_enable_ctrl(RCU_AHB_PERI_PORTA, ENABLE);
    gpio_bits_set(LED_GPIO_PORT, LED_GPIO_PIN);

    gpio_config.gpio_pin = LED_GPIO_PIN;
    gpio_config.gpio_mode = GPIO_MODE_OUTPUT;
    gpio_config.gpio_speed = GPIO_SPEED_LOW;
    gpio_config.gpio_out_type = GPIO_OUTPUT_PP;
    gpio_config.gpio_pull = GPIO_PULL_NO_PULL;
    gpio_init(LED_GPIO_PORT, &gpio_config);
}

static void uart_init(void)
{
    gpio_config_t gpio_config;
    usart_config_t usart_config;

    rcu_ahb_periph_clock_enable_ctrl(RCU_AHB_PERI_PORTA, ENABLE);

    /* PA9 = USART1_TX and PA10 = USART1_RX (multi-function 1). */
    gpio_mf_config(GPIOA, GPIO_PIN_NUM9, GPIO_MF_SEL1);
    gpio_mf_config(GPIOA, GPIO_PIN_NUM10, GPIO_MF_SEL1);

    gpio_config.gpio_pin = GPIO_PIN_9 | GPIO_PIN_10;
    gpio_config.gpio_mode = GPIO_MODE_MF;
    gpio_config.gpio_speed = GPIO_SPEED_HIGH;
    gpio_config.gpio_out_type = GPIO_OUTPUT_PP;
    gpio_config.gpio_pull = GPIO_PULL_UP;
    gpio_init(GPIOA, &gpio_config);

    rcu_apb2_periph_clock_enable_ctrl(RCU_APB2_PERI_USART1, ENABLE);
    usart_def_init(USART1);
    usart_config_struct_init(&usart_config);
    usart_config.usart_rate = UART_BAUD_RATE;
    usart_init(USART1, &usart_config);
    usart_enable_ctrl(USART1, ENABLE);
}

static void uart_write_char(uint8_t value)
{
    while (usart_flag_status_get(USART1, USART_FLAG_TXE) != SET)
    {
    }

    usart_data_send(USART1, value);
}

static void uart_write_string(const char *text)
{
    while (*text != '\0')
    {
        uart_write_char((uint8_t)*text);
        ++text;
    }
}

static void uart_write_fixed_digits(uint32_t value, uint8_t width)
{
    uint32_t divisor = 1U;
    uint8_t index;

    for (index = 1U; index < width; ++index)
    {
        divisor *= 10U;
    }

    while (divisor > 0U)
    {
        uart_write_char((uint8_t)('0' + ((value / divisor) % 10U)));
        divisor /= 10U;
    }
}

static uint8_t build_month(void)
{
    static const char *const month_names[] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };
    uint8_t month;

    for (month = 0U; month < 12U; ++month)
    {
        if ((__DATE__[0] == month_names[month][0]) &&
            (__DATE__[1] == month_names[month][1]) &&
            (__DATE__[2] == month_names[month][2]))
        {
            return (uint8_t)(month + 1U);
        }
    }

    return 1U;
}

static int32_t days_from_civil(int32_t year, uint32_t month, uint32_t day)
{
    int32_t era;
    uint32_t year_of_era;
    uint32_t adjusted_month;
    uint32_t day_of_year;
    uint32_t day_of_era;

    year -= (month <= 2U) ? 1 : 0;
    era = (year >= 0) ? (year / 400) : ((year - 399) / 400);
    year_of_era = (uint32_t)(year - (era * 400));
    adjusted_month = (month > 2U) ? (month - 3U) : (month + 9U);
    day_of_year = ((153U * adjusted_month + 2U) / 5U) + day - 1U;
    day_of_era = (year_of_era * 365U) + (year_of_era / 4U) - (year_of_era / 100U) + day_of_year;

    return (era * 146097) + (int32_t)day_of_era - 719468;
}

static void civil_from_days(int32_t days, uint32_t *year, uint32_t *month, uint32_t *day)
{
    int32_t era;
    uint32_t day_of_era;
    uint32_t year_of_era;
    uint32_t day_of_year;
    uint32_t month_prime;
    int32_t civil_year;

    days += 719468;
    era = (days >= 0) ? (days / 146097) : ((days - 146096) / 146097);
    day_of_era = (uint32_t)(days - (era * 146097));
    year_of_era = (day_of_era - (day_of_era / 1460U) + (day_of_era / 36524U) -
                   (day_of_era / 146096U)) / 365U;
    civil_year = (int32_t)year_of_era + (era * 400);
    day_of_year = day_of_era - ((365U * year_of_era) + (year_of_era / 4U) - (year_of_era / 100U));
    month_prime = ((5U * day_of_year) + 2U) / 153U;
    *day = day_of_year - (((153U * month_prime) + 2U) / 5U) + 1U;
    *month = (month_prime < 10U) ? (month_prime + 3U) : (month_prime - 9U);
    civil_year += (*month <= 2U) ? 1 : 0;
    *year = (uint32_t)civil_year;
}

static uint32_t build_epoch_seconds(void)
{
    uint32_t year = ((uint32_t)(__DATE__[7] - '0') * 1000U) +
                    ((uint32_t)(__DATE__[8] - '0') * 100U) +
                    ((uint32_t)(__DATE__[9] - '0') * 10U) +
                    (uint32_t)(__DATE__[10] - '0');
    uint32_t day = (uint32_t)((__DATE__[4] == ' ') ? 0 : (__DATE__[4] - '0')) * 10U +
                    (uint32_t)(__DATE__[5] - '0');
    uint32_t hour = ((uint32_t)(__TIME__[0] - '0') * 10U) + (uint32_t)(__TIME__[1] - '0');
    uint32_t minute = ((uint32_t)(__TIME__[3] - '0') * 10U) + (uint32_t)(__TIME__[4] - '0');
    uint32_t second = ((uint32_t)(__TIME__[6] - '0') * 10U) + (uint32_t)(__TIME__[7] - '0');

    return ((uint32_t)days_from_civil((int32_t)year, build_month(), day) * 86400U) +
           (hour * 3600U) + (minute * 60U) + second;
}

static void uart_write_timestamp(uint32_t elapsed_ms)
{
    uint32_t timestamp = wall_clock_base_seconds + (elapsed_ms / 1000U);
    uint32_t days = timestamp / 86400U;
    uint32_t seconds_in_day = timestamp % 86400U;
    uint32_t year;
    uint32_t month;
    uint32_t day;

    civil_from_days((int32_t)days, &year, &month, &day);

    uart_write_char('[');
    uart_write_fixed_digits(year, 4U);
    uart_write_char('-');
    uart_write_fixed_digits(month, 2U);
    uart_write_char('-');
    uart_write_fixed_digits(day, 2U);
    uart_write_char(' ');
    uart_write_fixed_digits(seconds_in_day / 3600U, 2U);
    uart_write_char(':');
    uart_write_fixed_digits((seconds_in_day / 60U) % 60U, 2U);
    uart_write_char(':');
    uart_write_fixed_digits(seconds_in_day % 60U, 2U);
    uart_write_string(" UTC+08:00] ");
}

static void handle_command(char *line, uint32_t length, uint8_t overflow,
                           uint32_t timestamp)
{
    uint32_t start = 0U;
    uint32_t end = length;
    uint32_t index;

    if (overflow != 0U)
    {
        uart_write_timestamp(timestamp);
        uart_write_string("ERR: line too long\r\n");
        return;
    }

    while ((start < end) && ((line[start] == ' ') || (line[start] == '\t')))
    {
        ++start;
    }
    while ((end > start) && ((line[end - 1U] == ' ') || (line[end - 1U] == '\t')))
    {
        --end;
    }

    for (index = start; index < end; ++index)
    {
        if ((line[index] >= 'A') && (line[index] <= 'Z'))
        {
            line[index] = (char)(line[index] + ('a' - 'A'));
        }
    }

    uart_write_timestamp(timestamp);
    if (((end - start) == 2U) && (line[start] == 'o') && (line[start + 1U] == 'n'))
    {
        gpio_bits_reset(LED_GPIO_PORT, LED_GPIO_PIN);
        uart_write_string("PA15 LED ON (LOW)\r\n");
    }
    else if (((end - start) == 3U) && (line[start] == 'o') &&
             (line[start + 1U] == 'f') && (line[start + 2U] == 'f'))
    {
        gpio_bits_set(LED_GPIO_PORT, LED_GPIO_PIN);
        uart_write_string("PA15 LED OFF (HIGH)\r\n");
    }
    else
    {
        uart_write_string("ERR: enter on or off\r\n");
    }
}

int main(void)
{
    char rx_line[RX_LINE_CAPACITY];
    uint32_t rx_length = 0U;
    uint8_t rx_overflow = 0U;
    uint8_t previous_was_cr = 0U;

    led_init();
    uart_init();

    if (SysTick_Config(SystemCoreClock / 1000U) != 0U)
    {
        while (1)
        {
        }
    }

    /* Compiler date/time is treated as Beijing time; SysTick advances it while powered. */
    wall_clock_base_seconds = build_epoch_seconds();
    uart_write_timestamp(system_millis);
    uart_write_string("Ready: enter on/off then press Enter (115200 8N1)\r\n");

    while (1)
    {
        if (usart_flag_status_get(USART1, USART_FLAG_RXNE) == SET)
        {
            uint8_t received = (uint8_t)usart_data_recv(USART1);

            if (received == '\r')
            {
                handle_command(rx_line, rx_length, rx_overflow, system_millis);
                rx_length = 0U;
                rx_overflow = 0U;
                previous_was_cr = 1U;
            }
            else if (received == '\n')
            {
                if (previous_was_cr == 0U)
                {
                    handle_command(rx_line, rx_length, rx_overflow, system_millis);
                    rx_length = 0U;
                    rx_overflow = 0U;
                }
                previous_was_cr = 0U;
            }
            else if ((received == '\b') || (received == 0x7FU))
            {
                previous_was_cr = 0U;
                if (rx_length > 0U)
                {
                    --rx_length;
                }
            }
            else
            {
                previous_was_cr = 0U;
                if (rx_length < (RX_LINE_CAPACITY - 1U))
                {
                    rx_line[rx_length++] = (char)received;
                }
                else
                {
                    rx_overflow = 1U;
                }
            }
        }

    }
}
